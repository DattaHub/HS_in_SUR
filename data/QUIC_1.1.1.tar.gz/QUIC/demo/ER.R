data("ER_692")
a = QUIC(S, rho = 0.5, path = NULL, tol = 1e-8, msg = 2, maxIter = 1000)

